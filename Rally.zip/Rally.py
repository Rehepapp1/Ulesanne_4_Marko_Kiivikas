import pygame  # Impordime pygame'i mooduli, et kasutada mänguarenduse funktsioone
import random  # Impordime random mooduli, et juhuslikke väärtusi genereerida

WIDTH = 640  # Määratleme mänguakna laiuse
HEIGHT = 480  # Määratleme mänguakna kõrguse
FPS = 60  # Määratleme mängu värskendussageduse kaadrites sekundis

BLACK = (0, 0, 0)  # Määratleme musta värvi RGB koodina
WHITE = (255, 255, 255)  # Määratleme valge värvi RGB koodina
RED = (255, 0, 0)  # Määratleme punase värvi RGB koodina
BLUE = (0, 0, 255)  # Määratleme sinise värvi RGB koodina

bg_image = pygame.image.load("bg_rally.jpg")  # Laadime taustapildi
car_image = pygame.image.load("f1_red.png")  # Laadime punase auto pildi
blue_car_image = pygame.image.load("f1_blue.png")  # Laadime sinise auto pildi

class Auto:  # Määratleme Auto klassi, mis esindab mänguautosid
    def __init__(self, x, y, image):  # Konstruktor, mis initsialiseerib auto omadused
        self.x = x  # X-koordinaat
        self.y = y  # Y-koordinaat
        self.image = pygame.transform.flip(image, False, True)  # Pöörame pilti vastupidiseks, et autod liiguksid ülevalt alla
        self.speed = random.randint(2, 5)  # Genereerime juhusliku kiiruse vahemikus 2-5

    def move(self):  # Meetod auto liigutamiseks
        self.y += self.speed  # Liigutame autot allapoole vastavalt kiirusele

        if self.y > HEIGHT:  # Kontrollime, kas auto on väljunud ekraanist
            self.y = 0  # Kui auto on väljunud, siis liigutame selle tagasi ülespoole

    def draw(self, screen):  # Meetod auto joonistamiseks ekraanile
        screen.blit(self.image, (self.x, self.y))  # Joonistame auto ekraanile

class Taust:  # Määratleme Taust klassi, mis esindab mängu tausta
    def __init__(self, image):  # Konstruktor, mis initsialiseerib tausta omadused
        self.image = image  # Taustapilt

    def draw(self, screen):  # Meetod tausta joonistamiseks ekraanile
        screen.blit(self.image, (0, 0))  # Joonistame tausta ekraanile

class PunaneAuto(Auto):  # Määratleme PunaneAuto klassi, mis on Auto klassi alamklass
    pass  # Pole vaja täiendavaid meetodeid lisada

center_offset = 190  # Muutuja, mis määratleb auto algusasukoha keskmele lähedase offseti

class Mäng:  # Määratleme Mäng klassi, mis esindab mängu põhifunktsionaalsust
    def __init__(self):  # Konstruktor, mis initsialiseerib mängu omadused
        pygame.init()  # Initsialiseerime pygame'i
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))  # Loome mänguakna
        self.clock = pygame.time.Clock()  # Loome kella mängu FPS-i hoidmiseks
        self.running = True  # Muutuja, mis näitab, kas mäng käib või mitte
        self.autod = []  # Loome tühja listi autode hoidmiseks
        self.skoor = 0  # Muutuja, mis hoiab mängija skoori

        self.taust = Taust(bg_image)  # Loome tausta objekti
        self.punane_auto = PunaneAuto(WIDTH // 2, HEIGHT - car_image.get_height(), car_image)  # Loome punase auto objekti

        for i in range(5):  # Loome 5 sinist autot
            # Juhuslik alguskoht nii x- kui ka y-koordinaadile
            start_x = random.randint(WIDTH // 2 - center_offset, WIDTH // 2 + center_offset - blue_car_image.get_width())
            start_y = random.randint(-HEIGHT, -HEIGHT // 2)
            self.autod.append(Auto(start_x, start_y, blue_car_image))  # Lisame uue sinise auto listi autod

            # Juhuslik kiirus
            self.autod[i].speed = random.randint(2, 5)  # Määrame autodele juhusliku kiiruse vahemikus 2-5

    def jookse(self):  # Meetod mängu jooksmiseks
        while self.running:  # Loop, mis käivitab mängu
            self.clock.tick(FPS)  # Piirame mängu FPS-i

            for event in pygame.event.get():  # Käime läbi kõik pygame sündmused
                if event.type == pygame.QUIT:  # Kui mänguaken suletakse
                    self.running = False  # Lõpetame mängu jooksmise

            self.taust.draw(self.screen)  # Joonistame tausta
            self.punane_auto.draw(self.screen)  # Joonistame punase auto

            for auto in self.autod:  # Käime läbi kõik sinised autod
                auto.move()  # Liigutame auto
                auto.draw(self.screen)  # Joonistame auto

                if auto.y > HEIGHT - blue_car_image.get_height():  # Kontrollime, kas auto on ekraanist väljunud
                    self.skoor += 1  # Suurendame mängija skoori
                    auto.y = random.randint(-HEIGHT, 0)  # Määrame autole juhusliku alguspositsiooni
                    auto.speed = random.randint(2, 5)  # Määrame autole juhusliku kiiruse vahemikus 2-5

            skoor_tekst = str(self.skoor)  # Teisendame skoori tekstiks
            skoor_pilt = pygame.font.Font(None, 32).render(skoor_tekst, True, WHITE)  # Loome skoori pildi
            self.screen.blit(skoor_pilt, (10, 10))  # Joonistame skoori ekraanile

            pygame.display.flip()  # Värskendame ekraani

mäng = Mäng()  # Loome mängu objekti
mäng.jookse()  # Käivitame mängu
